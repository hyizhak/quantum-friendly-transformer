# Falcon-H1 34B attention-input norm experiment

Model: `tiiuae/Falcon-H1-34B-Base`, revision
`db4eb5f380b8a94f2842ba5cc1b49095a244509d` (72 layers, hidden size 5120).

The measured tensor at layer `l` is the output of that layer's
`input_layernorm`. Falcon-H1 passes this tensor to `self_attn` after multiplying
it by `attention_in_multiplier`, which is 1.0 for this checkpoint. A direct
runtime comparison verified all 72 attention boundaries: every tensor was
exactly equal and the maximum absolute difference was 0.

For every token, the experiment computes

```text
token_l2(l, t) = sqrt(sum_j attention_input(l, t, j)^2)
```

The layer statistic is the median token norm. The figure reports its percentage
change relative to layer 1:

```text
100 * (median_l2(l) / median_l2(1) - 1)
```

Data: WikiText-103 raw test split, sequence lengths 128, 256, and 512, with a
shared budget of 1024 non-padding tokens per sequence length. The model ran in
bfloat16 on an A100 80GB GPU.

## Result

The post-affine attention-input norm is **not stable across depth** under the
5% criterion.

| Sequence length | Layer 1 median | Layer 72 median | Final change | Minimum change |
|---:|---:|---:|---:|---:|
| 128 | 30.701 | 211.648 | +589.38% | -71.84% |
| 256 | 30.701 | 211.513 | +588.94% | -72.88% |
| 512 | 30.701 | 212.753 | +592.98% | -73.59% |

The pre-affine RMS-normalized vector does remain constant: its median is
approximately `sqrt(5120) = 71.5542` at every layer, with maximum relative
deviation `3.93e-6`. Thus RMS normalization fixes the pre-affine norm, but the
learned per-coordinate affine scale makes the actual attention-input norm
direction-dependent and allows it to change substantially across layers.

The raw token-level data and run metadata remain in
`../../raw/deep_falcon_h1_34b_token_norms.parquet` and
`../../raw/deep_falcon_h1_34b_token_norms.parquet.metadata.json`.
