# ALBERT-XXLarge v2 shared-affine attention-input experiment

This experiment records the exact `hidden_states` argument received by every
logical self-attention call in `albert/albert-xxlarge-v2`. ALBERT repeats one
shared transformer block for 12 logical layers, so layers 2--12 receive outputs
formed with the same learned block-output LayerNorm affine parameters.

The WikiText-103 raw test split was evaluated at sequence lengths 128, 256, and
512 with 1024 non-padding tokens per sequence length. For each layer, the
reported statistic is the median per-token Euclidean norm.

The hidden dimension is 4096, so the pre-affine LayerNorm reference is
`sqrt(d) = 64`. The actual post-affine attention inputs are much smaller:

| Sequence length | Minimum median | Maximum median | Maximum change from layer 1 |
|---:|---:|---:|---:|
| 128 | 9.515 | 11.136 | 17.04% |
| 256 | 9.609 | 11.326 | 17.87% |
| 512 | 9.713 | 11.562 | 19.04% |

Thus this unmodified pretrained checkpoint demonstrates that the post-affine
attention-input norm need not be close to `sqrt(d)`. It remains bounded in a
narrow absolute interval but does not pass the experiment's strict 5% depth
constancy criterion.

For the shared block-output LayerNorm, the isotropic estimate
`sqrt(||gamma||_2^2 + ||beta||_2^2)` is 14.030. The difference from the observed
token medians shows that the norm depends on both the affine parameters and the
normalized activation directions.
