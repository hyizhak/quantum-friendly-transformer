# nGPT-800M exact attention-input norm experiment

Checkpoint: `p2o6e100/nGPT_800m`, revision
`46fe93e6466568e1c9276ee0119a60cd467641bd`.

This is a community-released, decoder-only nGPT checkpoint with approximately
775M parameters, 30 layers, hidden dimension 1280, and BF16 weights. It is a
modern hyperspherical normalized Transformer rather than a conventional
LayerNorm/RMSNorm LLM. The residual state is normalized to unit Euclidean norm
after every attention and MLP update, and that normalized state is the input to
the next attention module. The first-layer token embeddings are also unit norm.

The measurement is taken with a forward-pre-hook directly on every
`self_attn` module. It therefore records the exact `hidden_states` argument
received by attention, not a proxy tensor from a neighboring normalization
module.

Data: WikiText-103 raw test split, sequence lengths 128, 256, and 512, with a
shared budget of 1024 non-padding tokens at each sequence length.

## Result

The exact attention-input norm is one and is independent of
`sqrt(1280) = 35.7771`:

| Sequence length | Minimum layer median | Maximum layer median | Maximum depth change |
|---:|---:|---:|---:|
| 128 | 0.999855 | 1.000243 | 0.0257% |
| 256 | 0.999828 | 1.000295 | 0.0283% |
| 512 | 0.999897 | 1.000207 | 0.0214% |

All 30 logical attention boundaries were observed on every forward pass. The
small deviations from one come from BF16 storage and arithmetic.

As a minimal trained-checkpoint sanity check, two 512-token WikiText sequences
gave mean causal-language-model loss 2.7097 (perplexity 15.03), compared with
uniform-random loss `log(32000) = 10.3735`.

## Interpretation

This model satisfies the desired property through explicit unit-L2
normalization, not through learned LayerNorm affine parameters. Functionally,
attention always receives a normalized vector before its projections. It is
therefore a pre-attention-normalized modern decoder, but it should be described
as nGPT/hyperspherical normalization rather than as a conventional affine
Pre-LayerNorm architecture.

The checkpoint is lightly documented and is not an official NVIDIA release, so
that provenance limitation should be stated if it is used in a paper.
