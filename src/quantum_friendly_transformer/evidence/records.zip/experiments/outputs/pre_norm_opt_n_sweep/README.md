# Pre-norm OPT sequence-length sweep

This folder collects the OPT attention-input norm results for
`N = 128, 256, 512`, using eight WikiText samples per sequence length and a
shared 4096-token budget.

## Figures

- `figures/figure_pre_norm_opt_n_sweep_attention_input_across_layers.{pdf,png}`:
  combined OPT-family figure.
- `figures/figure_pre_norm_opt_n_sweep_attention_input_across_layers_facebook-opt-1-3b.{pdf,png}`:
  OPT-1.3B.
- `figures/figure_pre_norm_opt_n_sweep_attention_input_across_layers_facebook-opt-2-7b.{pdf,png}`:
  OPT-2.7B.
- `figures/figure_pre_norm_opt_n_sweep_attention_input_across_layers_facebook-opt-6-7b.{pdf,png}`:
  OPT-6.7B.
- `figures/figure_pre_norm_opt_n_sweep_attention_input_across_layers_facebook-opt-30b.{pdf,png}`:
  OPT-30B.

Each curve is the percentage change in the median post-affine LayerNorm-output
token norm sent into attention, relative to the first attention layer at the
same sequence length. Layer 1 is therefore 0%, with one curve per sequence
length.

## Tables

- `tables/summary.csv`: compact cross-N stability and scaling summary.
- `tables/attention_input_constancy_by_N.csv`: depth verdict for each model and N.
- `tables/pre_affine_constancy_by_N.csv`: pre-affine LayerNorm verdicts.
- `tables/block_output_constancy_by_N.csv`: residual-stream verdicts.
- `tables/layernorm_affine_summary.csv`: compact per-model gamma/beta audit.
- `tables/layernorm_affine_by_layer.csv`: per-layer gamma/beta statistics and
  predicted versus observed L2 norms.
- `tables/attention_input_boundary_verification.csv`: direct per-checkpoint
  verification that every recorded `self_attn_layer_norm` output is exactly
  the tensor received by `self_attn` (shared storage and zero numerical
  difference at all 136 tested layers).
- `tables/norm_by_layer.csv`: complete per-layer statistics.

The raw token-level data remains at
`../raw/pre_norm_opt_n_sweep_token_norms.parquet`; `metadata.json` records the
model revisions and complete experiment configuration.
