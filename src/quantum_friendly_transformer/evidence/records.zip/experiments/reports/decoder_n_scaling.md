# Decoder Z/N vs N Sweep

Retained decoder-only WikiText diagnostics for N = 512, 1024, 2048, 4096, 8192. This report is filtered to checkpoints whose configured maximum context is strictly greater than 8192. The latest long-context additions are `Qwen/Qwen2.5-0.5B-Instruct`, `Qwen/Qwen3-0.6B`, `google/gemma-3-1b-pt`, `deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B`, `microsoft/Phi-3-mini-128k-instruct`, `HuggingFaceTB/SmolLM3-3B`.

`mistralai/Mistral-7B-v0.2` is not exposed as an official base repo here, so the v0.2 row uses `mistralai/Mistral-7B-Instruct-v0.2`. Shorter-context runs such as GPT-2 XL, GPT-Neo, Pythia, OPT-1.3B, TinyLlama, Phi-1.5, Gemma-2B, and BLOOM are not retained in this long-context aggregate.

## Median Z / Valid Context

| Model | Max context | N=512 | N=1024 | N=2048 | N=4096 | N=8192 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `Qwen/Qwen2.5-0.5B-Instruct` | 32768 | 0.764021 | 0.375297 | 0.198949 | 0.132607 | 0.0853603 |
| `Qwen/Qwen1.5-1.8B` | 32768 | 0.229018 | 0.12776 | 0.0675351 | 0.0405504 | 0.0233699 |
| `Qwen/Qwen2.5-1.5B` | 131072 | 0.262458 | 0.161711 | 0.0911982 | 0.0607668 | 0.0381525 |
| `Qwen/Qwen3-0.6B` | 40960 | 935.36 | 622.647 | 391.92 | 271.649 | 166.317 |
| `Qwen/Qwen3-1.7B` | 40960 | 719.526 | 495.429 | 294.032 | 209.248 | 120.72 |
| `deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B` | 131072 | 0.711417 | 0.474742 | 0.304094 | 0.283506 | 0.409319 |
| `HuggingFaceTB/SmolLM3-3B` | 65536 | 0.153617 | 0.0875281 | 0.0505599 | 0.0339917 | 0.0208953 |
| `unsloth/Llama-3.2-1B-Instruct` | 131072 | 0.155364 | 0.0902466 | 0.0512199 | 0.0281018 | 0.0143631 |
| `mistralai/Mistral-7B-v0.1` | 32768 | 0.44228 | 0.292322 | 0.168044 | 0.13723 | 0.141171 |
| `mistralai/Mistral-7B-Instruct-v0.2` | 32768 | 0.325014 | 0.193428 | 0.112413 | 0.0762716 | 0.0514024 |
| `microsoft/Phi-3-mini-128k-instruct` | 131072 | 5.08219 | 2.59314 | 1.17538 | 0.505853 | 1.2598 |
| `microsoft/phi-4` | 16384 | 0.255353 | 0.147232 | 0.080737 | 0.0436506 | 0.0226943 |
| `google/gemma-3-1b-pt` | 32768 | 33.3698 | 24.7647 | 21.6183 | 21.7701 | 20.7568 |
| `google/gemma-3-4b-pt` | 131072 | 54.13 | 42.0967 | 34.701 | 43.0131 | 43.8292 |

## RMS/LayerNorm Denominator p5

| Model | Max context | N=512 | N=1024 | N=2048 | N=4096 | N=8192 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `Qwen/Qwen2.5-0.5B-Instruct` | 32768 | 0.0128972 | 0.0128972 | 0.0128551 | 0.012786 | 0.0128624 |
| `Qwen/Qwen1.5-1.8B` | 32768 | 0.0119325 | 0.0104641 | 0.0104641 | 0.0119325 | 0.0119325 |
| `Qwen/Qwen2.5-1.5B` | 131072 | 0.0184372 | 0.0194782 | 0.0199172 | 0.0204319 | 0.0204319 |
| `Qwen/Qwen3-0.6B` | 40960 | 0.022952 | 0.0224524 | 0.0232445 | 0.0232445 | 0.0232445 |
| `Qwen/Qwen3-1.7B` | 40960 | 0.0266123 | 0.0261612 | 0.0271379 | 0.0276012 | 0.0288145 |
| `deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B` | 131072 | 0.026076 | 0.026076 | 0.026076 | 0.0262566 | 0.0262566 |
| `HuggingFaceTB/SmolLM3-3B` | 65536 | 0.0687998 | 0.0685966 | 0.0687674 | 0.0694348 | 0.0690545 |
| `unsloth/Llama-3.2-1B-Instruct` | 131072 |  |  |  |  |  |
| `mistralai/Mistral-7B-v0.1` | 32768 | 0.00345093 | 0.00344465 | 0.00344465 | 0.00344936 | 0.00345834 |
| `mistralai/Mistral-7B-Instruct-v0.2` | 32768 | 0.0034477 | 0.0034477 | 0.0034477 | 0.0034477 | 0.00345249 |
| `microsoft/Phi-3-mini-128k-instruct` | 131072 | 0.0198865 | 0.0198865 | 0.0198865 | 0.0198865 | 0.0198865 |
| `microsoft/phi-4` | 16384 | 0.0129749 | 0.0124016 | 0.0119244 | 0.0122757 | 0.0119244 |
| `google/gemma-3-1b-pt` | 32768 | 1.0478 | 1.04777 | 1.04777 | 1.04777 | 1.04777 |
| `google/gemma-3-4b-pt` | 131072 | 0.970399 | 0.97043 | 0.970455 | 0.97045 | 0.970483 |

## Sources

| Source file | Rows | N values |
| --- | ---: | --- |
| `experiments/outputs/raw/diag_llama32_1b_wikitext_N512_1024_2048_4096_8192_light.parquet` | 671744 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_mistral7b_wikitext_N512_1024_2048_4096_8192_zonly.parquet` | 655360 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_mistral7b_instruct_v02_wikitext_N512_1024_2048_4096_8192.parquet` | 655360 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_qwen15_1p8b_wikitext_N512_1024_2048_4096_8192.parquet` | 245760 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_qwen25_1p5b_wikitext_N512_1024_2048_4096_8192.parquet` | 430080 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_qwen3_1p7b_wikitext_N512_1024_2048_4096_8192.parquet` | 286720 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_phi4_wikitext_N512_1024_2048_4096_8192.parquet` | 1024000 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_gemma3_4b_pt_wikitext_N512_1024_2048_4096_8192.parquet` | 174080 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_qwen25_0p5b_instruct_wikitext_N512_1024_2048_4096_8192.parquet` | 215040 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_qwen3_0p6b_wikitext_N512_1024_2048_4096_8192.parquet` | 286720 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_gemma3_1b_pt_wikitext_N512_1024_2048_4096_8192.parquet` | 66560 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_deepseek_r1_distill_qwen_1p5b_wikitext_N512_1024_2048_4096_8192.parquet` | 215040 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_phi3_mini_128k_instruct_wikitext_N512_1024_2048_4096_8192.parquet` | 655360 | 512 1024 2048 4096 8192 |
| `experiments/outputs/raw/diag_smollm3_3b_wikitext_N512_1024_2048_4096_8192.parquet` | 368640 | 512 1024 2048 4096 8192 |

Summary figures are `experiments/outputs/figures/figure_N_scaling_extended_decoder_Z_over_valid_context_absolute.png` and `experiments/outputs/figures/figure_N_scaling_extended_decoder_Z_over_valid_context_relative.png`.
