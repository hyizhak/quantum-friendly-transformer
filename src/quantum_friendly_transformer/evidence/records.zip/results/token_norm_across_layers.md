# Token L2 Norm Across Decoder Layers

## Protocol

- Models: `meta-llama/Llama-2-7b-hf` and `Qwen/Qwen2.5-14B`
- Data: the first eight non-overlapping 512-token chunks from the WikiText-103
  raw test split (4,096 tokens per model)
- Precision: bfloat16 inference; norms accumulated in float32
- Measurement: per-token L2 norm after the token embedding and after every
  decoder block. The model's final RMS-normalized output is recorded separately.
- Constancy criterion: every block-output median must remain within 5% of the
  first block's median.

## Results

| Model | First block | Quarter depth | Mid depth | Three-quarter depth | Final block | Final / first | Constant? |
|---|---:|---:|---:|---:|---:|---:|:---:|
| Llama 2 7B | 1.778 | 12.746 (L9) | 31.808 (L17) | 79.942 (L25) | 185.813 (L32) | 104.53x | No |
| Qwen2.5 14B | 22.240 | 84.215 (L13) | 108.642 (L25) | 271.979 (L37) | 882.103 (L48) | 39.66x | No |

The residual-stream token norm is not constant in either example. It grows
strongly with depth, especially in the final blocks. The separate final
RMSNorm reduces the median to 118.075 for Llama 2 7B and 198.470 for Qwen2.5
14B, but that does not make the unnormalized block-output trajectory constant.

## Immediately Before Self-Attention

The output of every block's input RMSNorm was hooked directly. This is the
exact hidden-state tensor passed into self-attention.

| Model | Layer 1 | Minimum | Maximum | Final layer | Final / first | Constant? |
|---|---:|---:|---:|---:|---:|:---:|
| Llama 2 7B | 3.651 | 3.651 (L1) | 34.058 (L26) | 27.219 (L32) | 7.46x | No |
| Qwen2.5 14B | 11.922 | 3.674 (L2) | 56.857 (L47) | 56.393 (L48) | 4.73x | No |

These exact attention-input norms are not constant under the same 5%
criterion. RMSNorm makes the unweighted, pre-affine vector have approximately
unit RMS, but the tensor sent into attention has also been multiplied by that
layer's learned per-coordinate RMSNorm weights. Consequently, its L2 norm need
not equal `sqrt(d)` and can vary with both layer and token direction.

## Before the Learned RMSNorm Affine Scale

| Model | Theoretical `sqrt(d)` | Layer 1 | Minimum | Maximum | Final layer | Maximum deviation | Constant? |
|---|---:|---:|---:|---:|---:|---:|:---:|
| Llama 2 7B | 64.000 | 62.211 | 62.211 | 64.000 | 64.000 | 2.80% | Yes |
| Qwen2.5 14B | 71.554 | 70.742 | 70.742 | 71.554 | 71.554 | 1.13% | Yes |

The pre-affine normalized token L2 is constant within 5% for both models and
rapidly converges to `sqrt(d)`. The small first-layer shortfall is the expected
effect of the RMSNorm epsilon when the embedding residual has relatively small
RMS.

Raw token values, layer summaries, the machine-readable verdict, and the
figure are retained under:

- `experiments/outputs/raw/token_l2_norm_across_layers.parquet`
- `experiments/outputs/aggregate_token_norm_across_layers/`
- `experiments/outputs/figures/figure_token_l2_norm_across_layers.{png,pdf}`
- `experiments/outputs/figures/figure_attention_input_l2_norm_across_layers.{png,pdf}`
- `experiments/outputs/figures/figure_pre_affine_attention_input_l2_norm_across_layers.{png,pdf}`
