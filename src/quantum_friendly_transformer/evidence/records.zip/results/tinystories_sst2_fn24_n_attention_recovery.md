# SST-2 FN24 recovery with sequence-length attention scaling

## Protocol

- Attention logits use `Q K^T / N` with a fixed padded tensor length `N=128`.
- All runs use a learnable Frobenius cap of 24 on transformer projection weights.
- Task and metric: GLUE SST-2 validation accuracy on all 872 examples.
- Recovery means accuracy is within 0.01 of the corresponding uncapped baseline target.
- TinyStories and OLMo train all model parameters. Mistral uses the existing `head_caps` recovery scope.

## Recovery summary

| Model | Baseline target | Recovery threshold | Best accuracy | Best step | Final accuracy | First recovery step | Recovered? |
|---|---:|---:|---:|---:|---:|---:|:---:|
| TinyStories-1M | 0.823394 | 0.813394 | 0.814220 | 5,000 | 0.814220 | 5,000 | yes |
| TinyStories-3M | 0.818807 | 0.808807 | 0.817661 | 3,000 | 0.808486 | 1,500 | yes |
| TinyStories-8M | 0.833716 | 0.823716 | 0.821101 | 3,000 | 0.808486 | - | no |
| TinyStories-28M | 0.825688 | 0.815688 | 0.844037 | 2,000 | 0.816514 | 2,000 | yes |
| TinyStories-33M | 0.845183 | 0.835183 | 0.819954 | 2,000 | 0.801606 | - | no |
| OLMo-1B-0724 | 0.933486 | 0.923486 | 0.847477 | 6,315 | 0.847477 | - | no |
| Mistral-7B-v0.1 | 0.917431 | 0.907431 | 0.683486 | 500 | 0.683486 | - | no |

The `1/N` FN24 model recovers for 1M, 3M, and 28M. It does not recover for 8M, 33M, OLMo-1B, or Mistral-7B under the scheduled recovery protocols.

## All checkpoint accuracies

| Model | Checkpoint step: accuracy |
|---|---|
| TinyStories-1M | 0: 0.516055; 600: 0.560780; 1,000: 0.721330; 1,500: 0.786697; 2,000: 0.769495; 3,000: 0.807339; 4,000: 0.802752; 5,000: 0.814220; 7,000: 0.813073; 10,000: 0.814220 |
| TinyStories-3M | 0: 0.528670; 600: 0.615826; 1,000: 0.776376; 1,500: 0.814220; 2,000: 0.791284; 3,000: 0.817661; 4,000: 0.809633; 5,000: 0.807339; 7,000: 0.803899; 10,000: 0.808486 |
| TinyStories-8M | 0: 0.509174; 600: 0.644495; 1,000: 0.814220; 1,500: 0.810780; 2,000: 0.805046; 3,000: 0.821101; 4,000: 0.819954; 5,000: 0.817661; 7,000: 0.806193; 10,000: 0.808486 |
| TinyStories-28M | 0: 0.509174; 600: 0.732798; 1,000: 0.778670; 1,500: 0.802752; 2,000: 0.844037; 3,000: 0.818807; 4,000: 0.822248; 5,000: 0.816514; 7,000: 0.816514; 10,000: 0.816514 |
| TinyStories-33M | 0: 0.510321; 600: 0.786697; 1,000: 0.769495; 1,500: 0.776376; 2,000: 0.819954; 3,000: 0.799312; 4,000: 0.810780; 5,000: 0.800459; 7,000: 0.808486; 10,000: 0.801606 |
| OLMo-1B-0724 | 0: 0.516055; 500: 0.782110; 1,000: 0.774083; 2,000: 0.834862; 3,000: 0.837156; 4,000: 0.846330; 5,000: 0.845183; 6,315: 0.847477 |
| Mistral-7B-v0.1 | 0: 0.521789; 100: 0.566514; 300: 0.673165; 500: 0.683486 |

## Raw outputs

- `experiments/outputs/raw/recovery_sst2_tinystories_1m_fn24_n_attention_steps10000.json`
- `experiments/outputs/raw/recovery_sst2_tinystories_3m_fn24_n_attention_steps10000.json`
- `experiments/outputs/raw/recovery_sst2_tinystories_8m_fn24_n_attention_steps10000.json`
- `experiments/outputs/raw/recovery_sst2_tinystories_28m_fn24_n_attention_steps10000.json`
- `experiments/outputs/raw/recovery_sst2_tinystories_33m_fn24_n_attention_steps10000.json`
- `experiments/outputs/raw/recovery_sst2_olmo_1b_fn24_n_attention_steps6315.json`
- `experiments/outputs/raw/recovery_sst2_mistral7b_fn24_n_attention_steps500.json`
