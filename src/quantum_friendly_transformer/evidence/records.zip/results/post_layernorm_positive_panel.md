# Positive Post-LayerNorm Norm-Stability Examples

## Selection protocol

We screened eight pretrained post-LayerNorm encoders at sequence length 512.
The sequence matrix \(S^{(\ell)}\) was captured immediately before every
attention layer, and the primary quantity was

\[
C_\ell(N)=\frac{\lVert S^{(\ell)}\rVert_F}{\sqrt{N}}.
\]

Before inspecting the panel results, a model was considered a depth-stable
candidate when

\[
\frac{\max_\ell C_\ell(512)}{\min_\ell C_\ell(512)}\leq 2.
\]

Candidates were then evaluated at \(N\in\{128,256,512\}\) using the same
4,096-token WikiText-103 test prefix at each sequence length. A candidate was
retained as a positive example when the largest fitted exponent in
\(\lVert S^{(\ell)}\rVert_F\propto N^{\beta_\ell}\) was at most 0.6. The 0.6
threshold allows finite-sample variation around the target exponent 0.5.

## Positive examples

| Model | Layers | \(C_1(512)\) | \(C_{\rm last}(512)\) | Depth max/min | Median \(\beta\) | Maximum \(\beta\) | Maximum \(C_\ell\) drift over \(N\) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BERT base | 12 | 17.026 | 24.290 | 1.427x | 0.512 | 0.547 | 1.067x |
| BERT large | 24 | 18.121 | 27.006 | 1.490x | 0.529 | 0.551 | 1.074x |
| RoBERTa large | 24 | 27.861 | 32.204 | 1.210x | 0.501 | 0.503 | 1.005x |
| ELECTRA base | 12 | 12.366 | 16.660 | 1.487x | 0.509 | 0.518 | 1.025x |
| ELECTRA large | 24 | 11.350 | 18.551 | 1.875x | 0.508 | 0.522 | 1.031x |

All five candidates pass both criteria. RoBERTa large is the strongest example:
its normalized Frobenius factor stays within a 1.21x band across 24 layers,
changes by at most 0.5% across the tested sequence lengths, and has a maximum
fitted exponent of 0.503.

These results provide finite-regime evidence that
\(\alpha_s^{(\ell)}=O(\sqrt{N})\) can remain stable through 12--24 layers in
standard pretrained post-LayerNorm models. They do not prove a uniform bound
for arbitrary model families or unbounded depth.

## Full depth screen

| Model | Layers | Depth max/min | Passed 2x screen? |
|---|---:|---:|:---:|
| BERT base | 12 | 1.427x | Yes |
| BERT large | 24 | 1.490x | Yes |
| RoBERTa base | 12 | 2.866x | No |
| RoBERTa large | 24 | 1.210x | Yes |
| ELECTRA small | 12 | 2.607x | No |
| ELECTRA base | 12 | 1.487x | Yes |
| ELECTRA large | 24 | 1.875x | Yes |
| DeBERTa-v2 XXLarge | 48 | 3.492x | No |

The full screen is retained because it shows that post-LayerNorm alone is not a
universal guarantee. The positive examples establish an empirical existence
claim; the negative examples delimit that claim.

## Suggested paper wording

> We evaluated the sequence-matrix normalization factor
> \(C_\ell=\lVert S^{(\ell)}\rVert_F/\sqrt{N}\) at every attention layer in a
> panel of pretrained post-LayerNorm encoders. Five models spanning 12--24
> layers maintained \(C_\ell\) within a factor of two across depth. For these
> models, layer-wise fits over \(N=128,256,512\) yielded maximum exponents from
> 0.503 to 0.551 in \(\lVert S^{(\ell)}\rVert_F\propto N^{\beta_\ell}\), close
> to the \(\sqrt{N}\) behavior assumed in our complexity analysis. This is
> finite-regime evidence rather than a universal consequence of LayerNorm; the
> full model panel is reported in the appendix.

## Artifacts

- Full screen:
  `experiments/outputs/aggregate_post_layernorm_panel_screen/`
- Positive-model scaling study:
  `experiments/outputs/aggregate_post_layernorm_positive_panel/`
- Full-screen figure:
  `experiments/outputs/figures/figure_post_layernorm_panel_screen.{png,pdf}`
- Positive-panel figure:
  `experiments/outputs/figures/figure_post_layernorm_positive_panel.{png,pdf}`
- Separate positive-model figures:
  `experiments/outputs/figures/figure_post_layernorm_positive_panel_<model>.{png,pdf}`
- Separate full-screen figures:
  `experiments/outputs/figures/figure_post_layernorm_panel_screen_<model>.{png,pdf}`
- Raw screen values:
  `experiments/outputs/raw/post_layernorm_panel_screen_token_norms.parquet`
- Raw positive-panel values:
  `experiments/outputs/raw/post_layernorm_positive_panel_token_norms.parquet`

All combined and per-model figures report the percentage change from the first
attention layer at each sequence length and omit a p5 band.
