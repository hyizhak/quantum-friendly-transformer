# SST-2 FN24 recovery with trainable alpha attention scaling

All nine retained model variants recovered with a learnable Frobenius cap of 24 and a score-scale controller initialized from `1 / (alpha_s^2 * alpha_w^2)`. Recovery means validation accuracy is within 0.01 of the corresponding uncapped target.

Models are loaded through Hugging Face `transformers.AutoModel*`. The runner imports both `apply_learnable_frobenius_caps` and `apply_attention_scaling` from `quantum_friendly_transformer.norm_transformer`; there is no second Hugging Face-specific FN implementation.

The 33M, 2Layers-33M, OLMo, and Mistral controllers received a controller-only native prior warmup and then remained trainable during SST-2. Earlier TinyStories variants trained their controllers directly from the calibrated alpha initialization. Every retained row has either a recorded nonzero task gradient norm or direct task-phase scale movement, and none freezes the controller.

| Model | Scale layout | Threshold | First recovery step | Recovery accuracy | Final scale mean | Task-trainable evidence |
|---|---:|---:|---:|---:|---:|:---:|
| `TinyStories-1M` | per_layer | 0.813394 | 3,000 | 0.817661 | 0.101371 | yes |
| `TinyStories-3M` | per_layer | 0.808807 | 4,000 | 0.811927 | 0.266345 | yes |
| `TinyStories-8M` | shared | 0.823716 | 4,000 | 0.831422 | 0.0763698 | yes |
| `TinyStories-28M` | per_layer | 0.815688 | 1,500 | 0.816514 | 0.0117112 | yes |
| `TinyStories-33M` | shared | 0.835183 | 2,000 | 0.838303 | 0.999952 | yes |
| `TinyStories-1Layer-21M` | per_layer | 0.796193 | 1,500 | 0.806193 | 0.0200219 | yes |
| `TinyStories-2Layers-33M` | shared | 0.847798 | 4,000 | 0.849771 | 1.00001 | yes |
| `OLMo-1B-0724-hf` | shared | 0.923486 | 3,000 | 0.927752 | 0.0884647 | yes |
| `Mistral-7B-v0.1` | shared | 0.907431 | 500 | 0.923165 | 0.0883895 | yes |

## Raw artifacts

- `experiments/outputs/raw/recovery_sst2_tinystories_1m_fn24_trainable_alpha_attention_steps20000.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_1m_fn24_trainable_alpha_attention_steps20000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_3m_fn24_trainable_alpha_attention_steps20000.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_3m_fn24_trainable_alpha_attention_steps20000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_8m_fn24_trainable_alpha_attention_retry_shared_scalelr3e2_steps5000.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_8m_fn24_trainable_alpha_attention_retry_shared_scalelr3e2_steps5000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_28m_fn24_trainable_alpha_attention_steps10000.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_28m_fn24_trainable_alpha_attention_steps10000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_33m_fn24_trainable_alpha_attention_tasktrainable_rngneutral_steps3000.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_33m_fn24_trainable_alpha_attention_tasktrainable_rngneutral_steps3000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_1layer_21m_fn24_trainable_alpha_attention_steps10000.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_1layer_21m_fn24_trainable_alpha_attention_steps10000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_2layers_33m_fn24_trainable_alpha_attention_tasktrainable_rngneutral_steps5000.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_2layers_33m_fn24_trainable_alpha_attention_tasktrainable_rngneutral_steps5000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_olmo_1b_fn24_trainable_alpha_attention_tasktrainable_steps6315.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_olmo_1b_fn24_trainable_alpha_attention_tasktrainable_steps6315.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_mistral7b_fn24_trainable_alpha_attention_tasktrainable_steps500.json`
  - checkpoint: `experiments/outputs/raw/recovery_sst2_mistral7b_fn24_trainable_alpha_attention_tasktrainable_steps500.fn24.recovery.pt`
