# Sequence Norms Across Post-LayerNorm Models

## Question

Does a post-LayerNorm architecture keep the sequence-matrix encoding factor
bounded through depth, as required by the quantum-transformer complexity?

For the sequence matrix entering attention at layer \(\ell\), the primary
diagnostic is

\[
C_\ell(N) = \frac{\lVert S^{(\ell)}\rVert_F}{\sqrt{N}}.
\]

Uniform \(C_\ell(N)=O(1)\) is sufficient for
\(\alpha_s^{(\ell)}=O(\sqrt{N})\). Numerical equality across layers is not
required, but systematic growth with layer count would enter the hidden
constant in the multilayer complexity.

## Protocol

- Models:
  - `bert-base-uncased`: 12 layers, hidden dimension 768.
  - `bert-large-uncased`: 24 layers, hidden dimension 1,024.
  - `microsoft/deberta-v2-xxlarge`: 48 layers, hidden dimension 1,536.
- All three use residual connections followed by LayerNorm. Hooks capture the
  exact sequence matrix entering every attention layer. For DeBERTa this also
  captures the normalized convolutional path after its first layer.
- Data: the same 4,096-token prefix of the WikiText-103 raw test split at every
  sequence length.
- Sequence lengths: 128, 256, and 512, producing 32, 16, and 8 non-overlapping
  chunks respectively.
- Precision: bfloat16 inference on an NVIDIA A100; norms accumulated in
  float32.
- LayerNorm denominator: per-token standard deviation before the learned
  affine transformation.
- The spectral norm is an eight-step power-iteration estimate. The Frobenius
  norm is exact.

## Depth stability

The following values use \(N=512\) and the exact sequence matrix entering
attention.

| Model | Layers | Layer 1 \(C_\ell\) | Last-layer \(C_\ell\) | Last / first | Maximum \(C_\ell\) |
|---|---:|---:|---:|---:|---:|
| BERT base | 12 | 17.026 | 24.290 | 1.43x | 24.290 |
| BERT large | 24 | 18.121 | 27.006 | 1.49x | 27.006 |
| DeBERTa-v2 XXLarge | 48 | 14.911 | 52.064 | 3.49x | 52.064 |

BERT base and large remain within finite, relatively narrow ranges, although
their relevant factors are not constant numerically. The 48-layer DeBERTa
checkpoint shows substantial depth dependence. At layer 48 its median token
norm is 51.427, its p95 is 71.123, and its maximum is 79.796, so the increase is
not caused by a single outlier.

The maximum estimated spectral factor
\(\lVert S^{(\ell)}\rVert_2/\sqrt{N}\) at \(N=512\) is 15.994 for BERT base,
17.963 for BERT large, and 47.499 for DeBERTa.

## Sequence-length scaling

At each layer we fit

\[
\lVert S^{(\ell)}\rVert_F \propto N^{\beta_\ell}.
\]

| Model | Minimum \(\beta_\ell\) | Median \(\beta_\ell\) | Maximum \(\beta_\ell\) | Largest change in \(C_\ell\) over \(N\) |
|---|---:|---:|---:|---:|
| BERT base | 0.492 | 0.512 | 0.547 | 1.067x |
| BERT large | 0.507 | 0.529 | 0.551 | 1.074x |
| DeBERTa-v2 XXLarge | 0.462 | 0.551 | 0.715 | 1.348x |

The BERT results are close to the desired \(\sqrt{N}\) scaling throughout the
network. DeBERTa has a similar median exponent, but several later layers show
additional sequence-length dependence. The maximum exponent, 0.715, occurs at
layer 41, where \(C_\ell\) increases from 17.946 to 24.193 between the tested
sequence lengths.

Three sequence lengths cannot establish an asymptotic exponent. These fits
should be interpreted as finite-regime diagnostics rather than proofs.

## LayerNorm denominators

Across both residual-plus-LayerNorm operations in every block:

| Model | Minimum | p0.1 | p1 | Median |
|---|---:|---:|---:|---:|
| BERT base | 0.153 | 0.374 | 0.567 | 0.962 |
| BERT large | 0.145 | 0.286 | 0.429 | 0.943 |
| DeBERTa-v2 XXLarge | 0.097 | 0.100 | 0.211 | 0.934 |

The typical denominator remains order one, but DeBERTa has a noticeably
heavier lower tail. Since the detailed quantum runtime contains inverse
LayerNorm factors, this should be reported separately from the sequence norm.

## Interpretation

Post-LayerNorm is useful but is not, by itself, evidence that the relevant
block-encoding factor is uniform in depth. Standard pretrained models use
learned, coordinate-wise LayerNorm gains and biases. Consequently,
standardization fixes the pre-affine variance but does not force the actual
post-affine token norm to one.

The paper's special choice \(\gamma=1/\sqrt{d}\), \(\beta=0\) would force each
post-LayerNorm token to unit norm and therefore guarantee
\(\lVert S^{(\ell)}\rVert_F=\sqrt{N}\) by construction. The quantity
`frobenius_over_sqrt_nd` in the output tables is only a dimension-normalized
comparison; it is not a forward pass with modified LayerNorm parameters.

These experiments support a qualified response to the depth concern:

1. The favorable \(\sqrt{N}\) behavior is empirically stable through 12 and 24
   BERT layers in the tested regime.
2. A 48-layer post-LayerNorm checkpoint shows that the layer-dependent
   prefactor can still grow substantially and can acquire additional
   sequence-length dependence.
3. The stated multilayer complexity should therefore be presented as
   conditional on a uniform per-layer bound, or enforced using the paper's
   explicit unit-token normalization rather than inferred from the presence
   of LayerNorm alone.

## Artifacts

- Runner: `experiments/runners/diagnostics/post_layernorm_norm_across_layers.py`
- Raw token values: `experiments/outputs/raw/post_layernorm_token_norms.parquet`
- Per-sample sequence norms:
  `experiments/outputs/aggregate_post_layernorm_norms/sequence_norm_by_sample.csv`
- Layer summaries:
  `experiments/outputs/aggregate_post_layernorm_norms/norm_by_layer.csv`
- Sequence-length fits:
  `experiments/outputs/aggregate_post_layernorm_norms/sequence_length_scaling_by_layer.csv`
- Depth summary:
  `experiments/outputs/aggregate_post_layernorm_norms/depth_stability.csv`
- Figure:
  `experiments/outputs/figures/figure_post_layernorm_sequence_factor_across_layers.{png,pdf}`

The figure reports the percentage change from the first attention layer at
each sequence length and does not include a p5 band.
