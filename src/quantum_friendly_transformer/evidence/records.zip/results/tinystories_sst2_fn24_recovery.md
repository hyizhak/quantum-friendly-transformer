# TinyStories SST-2 FN24 recovery

## Protocol

- Models: `roneneldan/TinyStories-{1M,3M,8M,28M,33M}`.
- Task: GLUE SST-2 accuracy, full validation split.
- Wrapper: decoder backbone with final-token pooling and a learned SST-2 `score` head.
- Training: full model trainable, AdamW, LR `2e-4`, weight decay `0.01`, warmup ratio `0.06`, max length `128`, fixed padding, batch size `16`, grad accumulation `2`, BF16.
- Recovery criterion: capped accuracy must be within `0.01` absolute accuracy of the uncapped baseline target used for that comparison.
- Cap tested here: FN24 only, as requested. The 1M artifact also includes a wider cap sweep, but the table reports its FN24 row.

## Original recovery results

| Model | Baseline | Threshold | FN24 best | Best step | Recovered? | First recovered step | Capped matrices | Artifact |
| --- | ---: | ---: | ---: | ---: | --- | ---: | ---: | --- |
| `roneneldan/TinyStories-1M` | `0.769495` | `0.759495` | `0.760321` | 600 | yes | 600 | 48 | `experiments/outputs/raw/recovery_sst2_tinystories_1m_caps1_48_steps600_fulltrain.json` |
| `roneneldan/TinyStories-3M` | `0.790138` | `0.780138` | `0.798165` | 1000 | yes | 600 | 48 | `experiments/outputs/raw/recovery_sst2_tinystories_3m_fn24_steps1000_fulltrain.json` |
| `roneneldan/TinyStories-8M` | `0.794725` | `0.784725` | `0.807339` | 600 | yes | 600 | 48 | `experiments/outputs/raw/recovery_sst2_tinystories_8m_fn24_steps600_fulltrain.json` |
| `roneneldan/TinyStories-28M` | `0.818807` | `0.808807` | `0.829128` | 600 | yes | 600 | 48 | `experiments/outputs/raw/recovery_sst2_tinystories_28m_fn24_steps600_fulltrain.json` |
| `roneneldan/TinyStories-33M` | `0.847477` | `0.837477` | `0.838303` | 2000 | yes | 2000 | 24 | `experiments/outputs/raw/recovery_sst2_tinystories_33m_fn24_steps3000_fulltrain_target847477.json` |

## Notes

- FN24 recovered for all 5 standard TinyStories models against the original fixed-run baseline targets after extending 33M to 3000 steps.
- The 33M model has the strongest uncapped baseline. It did not recover by 1000 steps in the first run, but crossed the fixed threshold at step 2000 in the longer FN24-only run, then drifted back below threshold by step 3000.
- The 1M wider sweep found smaller caps do not recover by 600 steps until cap 16; FN24 also recovers at step 600.


## Stricter baseline recheck

Baseline-only runs use the same SST-2 setup as above, with the uncapped model trained longer and the best validation checkpoint selected after observing a later validation drop. Under these stricter baselines, the existing FN24 recovery runs still recover for 28M, 33M, and the d=1024 TinyStories variants. The existing 1M, 3M, and 8M FN24 runs do not meet the stricter thresholds and would need longer or stronger capped recovery runs to re-establish recovery.

| Model | Strict baseline | Best baseline step | Strict threshold | Existing FN24 best | FN24 step | Recovered under strict baseline? | Strict baseline artifact |
| --- | ---: | ---: | ---: | ---: | ---: | --- | --- |
| `roneneldan/TinyStories-1M` | `0.823394` | 3000 | `0.813394` | `0.760321` | 600 | no | `experiments/outputs/raw/baseline_sst2_tinystories_1m_strict_steps10000_fulltrain.json` |
| `roneneldan/TinyStories-3M` | `0.818807` | 4000 | `0.808807` | `0.798165` | 1000 | no | `experiments/outputs/raw/baseline_sst2_tinystories_3m_strict_steps5000_fulltrain.json` |
| `roneneldan/TinyStories-8M` | `0.833716` | 1500 | `0.823716` | `0.807339` | 600 | no | `experiments/outputs/raw/baseline_sst2_tinystories_8m_strict_steps5000_fulltrain.json` |
| `roneneldan/TinyStories-28M` | `0.825688` | 4000 | `0.815688` | `0.829128` | 600 | yes | `experiments/outputs/raw/baseline_sst2_tinystories_28m_strict_steps5000_fulltrain.json` |
| `roneneldan/TinyStories-33M` | `0.845183` | 4000 | `0.835183` | `0.838303` | 2000 | yes | `experiments/outputs/raw/baseline_sst2_tinystories_33m_strict_steps5000_fulltrain.json` |
| `roneneldan/TinyStories-1Layer-21M` | `0.806193` | 1000 | `0.796193` | `0.815367` | 2000 | yes | `experiments/outputs/raw/recovery_sst2_tinystories_1layer_21m_d1024_fn24_steps3000_fulltrain.json` |
| `roneneldan/TinyStories-2Layers-33M` | `0.857798` | 2000 | `0.847798` | `0.849771` | 4000 | yes | `experiments/outputs/raw/recovery_sst2_tinystories_2layers_33m_d1024_fn24_steps5000_fulltrain_target857798.json` |


## Strict-threshold FN24 reruns

Only the models that failed the stricter recheck above were rerun. The already-confirmed 28M, 33M, and d=1024 variants were not rerun.

| Model | Strict baseline | Strict threshold | Rerun FN24 best | Best step | Recovered? | First recovered step | Artifact |
| --- | ---: | ---: | ---: | ---: | --- | ---: | --- |
| `roneneldan/TinyStories-1M` | `0.823394` | `0.813394` | `0.805046` | 3000 | no | - | `experiments/outputs/raw/recovery_sst2_tinystories_1m_fn24_stricttarget823394_steps10000_fulltrain.json` |
| `roneneldan/TinyStories-3M` | `0.818807` | `0.808807` | `0.805046` | 7000 | no | - | `experiments/outputs/raw/recovery_sst2_tinystories_3m_fn24_stricttarget818807_steps10000_fulltrain.json` |
| `roneneldan/TinyStories-8M` | `0.833716` | `0.823716` | `0.831422` | 1500 | yes | 1500 | `experiments/outputs/raw/recovery_sst2_tinystories_8m_fn24_stricttarget833716_steps10000_fulltrain.json` |

## d=1024 TinyStories checkpoints

Two non-instruct TinyStories checkpoints have hidden size `d=1024`. Both recover under the same SST-2 FN24 protocol.

| Model | Layers | Baseline | Threshold | FN24 best | Best step | Recovered? | First recovered step | Capped matrices | Artifact |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | --- |
| `roneneldan/TinyStories-1Layer-21M` | 1 | `0.806193` | `0.796193` | `0.815367` | 2000 | yes | 600 | 6 | `experiments/outputs/raw/recovery_sst2_tinystories_1layer_21m_d1024_fn24_steps3000_fulltrain.json` |
| `roneneldan/TinyStories-2Layers-33M` | 2 | `0.857798` | `0.847798` | `0.849771` | 4000 | yes | 4000 | 12 | `experiments/outputs/raw/recovery_sst2_tinystories_2layers_33m_d1024_fn24_steps5000_fulltrain_target857798.json` |
