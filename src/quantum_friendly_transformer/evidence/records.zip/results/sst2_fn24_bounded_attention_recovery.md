# SST-2 FN24 recovery with a strict alpha denominator bound

All 9 bounded reruns completed; 3/9 met their corresponding SST-2 recovery thresholds. A failed recovery remains a valid completed strict-bound experiment.

Every adapter-install row, every recorded evaluation checkpoint, and every final controller row satisfies `scale_to_alpha_ratio <= 1` and `score_denominator >= score_denominator_floor`. The report checked 297 recorded controller rows. The implemented floor is also no smaller than `effective_alpha_s^2 * alpha_w^2`, including calibrated alpha values.

| Model | Layout | Threshold | Recovered | First recovery | Best accuracy | Final scale / alpha max | Minimum D / floor |
|---|---:|---:|:---:|---:|---:|---:|---:|
| `TinyStories-1M` | per_layer | 0.813394 | no | — | 0.805046 | 1 | 1 |
| `TinyStories-3M` | per_layer | 0.808807 | yes | 4,000 | 0.814220 | 1 | 1 |
| `TinyStories-8M` | shared | 0.823716 | no | — | 0.816514 | 1 | 1 |
| `TinyStories-28M` | per_layer | 0.815688 | yes | 2,000 | 0.829128 | 1 | 1 |
| `TinyStories-33M` | shared | 0.835183 | no | — | 0.832569 | 1 | 1 |
| `TinyStories-1Layer-21M` | per_layer | 0.796193 | yes | 1,000 | 0.805046 | 1 | 1 |
| `TinyStories-2Layers-33M` | shared | 0.847798 | no | — | 0.816514 | 1 | 1 |
| `OLMo-1B-0724-hf` | shared | 0.923486 | no | — | 0.830275 | 1 | 1 |
| `Mistral-7B-v0.1` | shared | 0.907431 | no | — | 0.616972 | 1 | 1 |

## Raw artifacts

- `experiments/outputs/raw/recovery_sst2_tinystories_1m_fn24_bounded_alpha_attention_steps20000.json`
  - recovery checkpoint: none (threshold not met)
- `experiments/outputs/raw/recovery_sst2_tinystories_3m_fn24_bounded_alpha_attention_steps20000.json`
  - recovery checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_3m_fn24_bounded_alpha_attention_steps20000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_8m_fn24_bounded_alpha_attention_shared_scalelr3e2_steps5000.json`
  - recovery checkpoint: none (threshold not met)
- `experiments/outputs/raw/recovery_sst2_tinystories_28m_fn24_bounded_alpha_attention_steps10000.json`
  - recovery checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_28m_fn24_bounded_alpha_attention_steps10000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_33m_fn24_bounded_alpha_attention_shared_steps3000.json`
  - recovery checkpoint: none (threshold not met)
- `experiments/outputs/raw/recovery_sst2_tinystories_1layer_21m_fn24_bounded_alpha_attention_steps10000.json`
  - recovery checkpoint: `experiments/outputs/raw/recovery_sst2_tinystories_1layer_21m_fn24_bounded_alpha_attention_steps10000.fn24.recovery.pt`
- `experiments/outputs/raw/recovery_sst2_tinystories_2layers_33m_fn24_bounded_alpha_attention_shared_steps5000.json`
  - recovery checkpoint: none (threshold not met)
- `experiments/outputs/raw/recovery_sst2_olmo_1b_fn24_bounded_alpha_attention_shared_steps6315.json`
  - recovery checkpoint: none (threshold not met)
- `experiments/outputs/raw/recovery_sst2_mistral7b_fn24_bounded_alpha_attention_shared_steps500.json`
  - recovery checkpoint: none (threshold not met)
